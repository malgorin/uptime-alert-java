package com.uptimealert.utime_alert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtimeAlertApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtimeAlertApplication.class, args);
	}

}
